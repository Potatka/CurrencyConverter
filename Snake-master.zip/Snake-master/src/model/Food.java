package model;

import com.sun.prism.paint.Color;
import javafx.scene.shape.Circle;

public class Food {

    Circle foodCircle;
    int posY;
    int posX;
    public Food() {



    }

    public Circle spawnFood() {

        foodCircle = new Circle(50);
        foodCircle.setTranslateX(20);
        foodCircle.setTranslateX(50);

    return foodCircle;
    }
}
