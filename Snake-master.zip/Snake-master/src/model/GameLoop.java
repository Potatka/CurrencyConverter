package model;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;
import javafx.scene.shape.Rectangle;

import static javafx.scene.input.KeyCode.*;

public class GameLoop {
    Scene scene;
    int moveDirection;
    int score;
    boolean foodSpawned;

    public GameLoop(Scene scene) {
        this.scene = scene;
        moveDirection = 1;
        foodSpawned = false;

    }

    public void startCycle(Snake snake, Food food) {
        Timeline timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);
        Rectangle snakeHead = snake.returnNode();
        Circle foodNode = food.spawnFood();
        KeyFrame kf = new KeyFrame(Duration.seconds(0.17),
                new EventHandler<ActionEvent>() {



                    public void handle(ActionEvent event) {
                      //  while(!foodSpawned){
                            food.spawnFood();
                            foodSpawned = true;

                        movingSnake(snakeHead);
                        System.out.println(snakeHead.getTranslateY());
                        System.out.println(snakeHead.getTranslateX());

                    }
                });


        timeline.getKeyFrames().add(kf);
        timeline.play();
    }

    private void moveSnake(Rectangle snakeHead, int direction) {
        switch (direction) {
            case 1:
                snakeHead.setTranslateX(snakeHead.getTranslateX() + 10); break;
            case 2:
                snakeHead.setTranslateY(snakeHead.getTranslateY() + 10); break;
            case 3:
                snakeHead.setTranslateX(snakeHead.getTranslateX() - 10); break;
            case 4:
                snakeHead.setTranslateY(snakeHead.getTranslateY() - 10); break;

        }


    }
    private void moveCircleOnKeyPress(Scene scene, Rectangle snakeHead) {

        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {

            @Override
            public void handle(KeyEvent event) {

                switch (event.getCode()) {

                    case UP:
                       moveDirection = 4;
                        break;

                    case RIGHT:
                       moveDirection = 1;
                        break;

                    case DOWN:
                     moveDirection = 2;
                        break;

                    case LEFT:
                      moveDirection = 3;
                        break;

                }

            }

        });


    }

    public void movingSnake(Rectangle snakeHead) {
        moveSnake(snakeHead, moveDirection);
        moveCircleOnKeyPress(scene, snakeHead);

    }
}







