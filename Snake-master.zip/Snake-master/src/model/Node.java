package model;


import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * Created by abyss on 8/17/2017.
 */
public class Node {

    Rectangle snakeHead;

    public static int count = 0;
    private int id;
    private int posY;
    private int posX;
    public Node() {

        snakeHead = new Rectangle(15,15, Color.ROYALBLUE);

        snakeHead.setTranslateX(0);
        snakeHead.setTranslateY(200);

        count++;
        id = count;
    }

    public Rectangle getNode() {
        snakeHead.setLayoutX(posX);
        snakeHead.setLayoutY(posY);
        return snakeHead;
    }




}
