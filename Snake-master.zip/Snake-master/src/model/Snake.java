package model;

import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by abyss on 8/17/2017.
 */
public class Snake {

    List<Node> nodeList;

    public Snake() {
        Node firstNode = new Node();
        nodeList = new ArrayList<>();
        addNode(firstNode);

    }
    public void addNode(Node node) {
        nodeList.add(node);


    }

    public Rectangle returnNode() {
        Node currentNode = nodeList.get(0);

        return currentNode.getNode();
    }




}